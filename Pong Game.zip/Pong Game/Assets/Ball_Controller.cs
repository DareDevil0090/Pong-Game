﻿using UnityEngine;
using System.Collections;
public class Ball_Controller : MonoBehaviour {
	private Rigidbody2D rb;
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		StartCoroutine (Pause ());
	}
	
	// Update is called once per frame
	void Update () {
		if (this.transform.position.x >= 18.1f) {
			this.transform.position=new Vector3(0f,0f,0f);
			StartCoroutine (Pause ());
		}
		if (this.transform.position.x <= -18.1f) {
			this.transform.position=new Vector3(0f,0f,0f);
			StartCoroutine (Pause ());
		}
	}
	IEnumerator Pause()
	{
		int directionX = Random.Range (-1,2);
		int directionY = Random.Range (1,3);
		if (directionX == 0) {
			directionX=1;
		}
		rb.velocity = new Vector2 (0f,0f);
		yield return new WaitForSeconds (1);
		rb.velocity = new Vector2 (8f * directionX,8f * directionY);
	}

}
